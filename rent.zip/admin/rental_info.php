
<style>

#margin-top {
	margin-top: 100px;
}

#margin-bottom {
	margin-top: 216px;
}


body {
  font-family: "Chakra Petch", sans-serif;
  color: #1E1D1D;
}


</style>



<?php
	 $sql="select * from member";
	 $result=$db->query($sql);
	 $row=$result->fetch_array(MYSQLI_BOTH);
 ?>



<?php
$strKeyword=null;
if(isset($_POST["txtKeyword"])){
$strKeyword=$_POST["txtKeyword"];
}
?>

<div id="margin-top">
</div>

<h3>ข้อมูลการเช่า</h3>

<html>
  <?php
      $jan=0;
      $fub=0;
      $mar=0;
      $Apr=0;
      $May=0;
      $Jun=0;

      $Jul=0;
      $Aug=0;
      $Sep=0;
      $Oct=0;
      $Nov=0;
      $Dec=0;

      $sql="select month(od_date_start) from rent_order";
      $result=$db->query($sql);
      while($row=$result->fetch_array(MYSQLI_ASSOC)){
        if($row["month(od_date_start)"]==1){
          $jan++;
        }
        if($row["month(od_date_start)"]==2){
          $fub++;
        }
        if($row["month(od_date_start)"]==3){
          $mar++;
        }
        if($row["month(od_date_start)"]==4){
          $Apr++;
        }
        if($row["month(od_date_start)"]==5){
          $May++;
        }
        if($row["month(od_date_start)"]==6){
          $Jun++;
        }


        if($row["month(od_date_start)"]==7){
          $Jul++;
        }
        if($row["month(od_date_start)"]==8){
          $Aug++;
        }
        if($row["month(od_date_start)"]==9){
          $Sep++;
        }
        if($row["month(od_date_start)"]==10){
          $Oct++;
        }
        if($row["month(od_date_start)"]==11){
          $Nov++;
        }
        if($row["month(od_date_start)"]==12){
          $Dec++;
        }

}
      $all=$jan+$fub+$mar+$Apr+$May+$Jun+$Jul+$Aug+$Sep+$Oct+$Nov+$Dec;
?>


  <head>


    <!-- <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

		google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawBasic);

function drawBasic() {

      var data = new google.visualization.DataTable();
      data.addColumn('timeofday', 'Time of Year');
      data.addColumn('number', 'จำนวน');

      data.addRows([
        [{v: [8, 0, 0], f: 'มกราคม'}, <?=$jan?>],
        [{v: [9, 0, 0], f: 'กุมภาพันธ์'}, <?=$fub?>],
        [{v: [10, 0, 0], f:'มีนาคม'}, <?=$mar?>],
        [{v: [11, 0, 0], f: 'เมษายน'}, <?=$Apr?>],
        [{v: [12, 0, 0], f: 'พฤษภาคม'}, <?=$May?>],
        [{v: [13, 0, 0], f: 'มิถุนายน'}, <?=$Jun?>],

        [{v: [14, 0, 0], f: 'กรกฎาคม'}, <?=$Jul?>],
        [{v: [15, 0, 0], f: 'สิงหาคม'}, <?=$Aug?>],
        [{v: [16, 0, 0], f: 'กันยายน'}, <?=$Sep?>],
        [{v: [17, 0, 0], f: 'ตุลาคม'}, <?=$Oct?>],
				[{v: [18, 0, 0], f: 'พฤศจิกายน'}, <?=$Nov?>],
				[{v: [19, 0, 0], f: 'ธันวาคม'}, <?=$Dec?>]


      ]);



      var options = {
        title: 'สถิติจำนวนการเช่าอุปกรณ์',
        hAxis: {
          viewWindow: {
            min: [7, 30, 0],
            max: [20, 30, 0]
          }
        },
        vAxis: {
          title: 'จำนวน  (คน)'
        }
      };

      var chart = new google.visualization.ColumnChart(
        document.getElementById('chart_div'));

      chart.draw(data, options);
    } -->


<!-- // ************************************************************************
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['เดือน', 'จำนวน(คน)'],
          ['มกราคม',  <?=$jan?>],
          ['กุมภาพันธ์', <?=$fub?>],
          ['มีนาคม',  <?=$mar?>],
          ['เมษายน',  <?=$Apr?>],
          ['พฤษภาคม',  <?=$May?>],
          ['มิถุนายน',  <?=$Jun?>],

          ['กรกฎาคม',  <?=$Jul?>],
          ['สิงหาคม',  <?=$Aug?>],
          ['กันยายน',  <?=$Sep?>],
          ['ตุลาคม',  <?=$Oct?>],
          ['พฤศจิกายน',  <?=$Nov?>],
          ['ธันวาคม',  <?=$Dec?>]
        ]);

        var options = {
          title: 'จำนวน(คน)',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }

			// var myBarChart = new Chart(ctx, {
			//     type: 'bar',
			//     data: data,
			//     options: options
			// });
    </script> -->


  </head>
  <body>
		<!-- Styles -->
		<style>
		#chartdiv {
		  width: 100%;
		  height: 500px;
		}
		</style>

		<!-- Resources -->
		<script src="https://cdn.amcharts.com/lib/4/core.js"></script>
		<script src="https://cdn.amcharts.com/lib/4/charts.js"></script>
		<script src="https://cdn.amcharts.com/lib/4/themes/animated.js"></script>

		<!-- Chart code -->
		<script>
		am4core.ready(function() {

		// Themes begin
		am4core.useTheme(am4themes_animated);
		// Themes end

		// Create chart instance
		var chart = am4core.create("chartdiv", am4charts.XYChart);
		chart.scrollbarX = new am4core.Scrollbar();

		// Add data
		chart.data = [{
		  "country": "มกราคม",
		  "visits": <?=$jan?>
		}, {
		  "country": "กุมภาพันธ์",
		  "visits": <?=$fub?>
		}, {
		  "country": "มีนาคม",
		  "visits": <?=$mar?>
		}, {
		  "country": "เมษายน",
		  "visits": <?=$Apr?>
		}, {
		  "country": "พฤษภาคม",
		  "visits":  <?=$May?>
		}, {
		  "country": "มิถุนายน",
		  "visits": <?=$Jun?>
		}, {
		  "country": "กรกฎาคม",
		  "visits": <?=$Jul?>
		}, {
		  "country": "สิงหาคม",
		  "visits": <?=$Aug?>
		}, {
		  "country": "กันยายน",
		  "visits": <?=$Sep?>
		}, {
		  "country": "ตุลาคม",
		  "visits": <?=$Oct?>
		}, {
		  "country": "พฤศจิกายน",
		  "visits":  <?=$Nov?>
		}, {
		  "country": "ธันวาคม",
		  "visits": <?=$Dec?>

		}];

		// Create axes
		var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
		categoryAxis.dataFields.category = "country";
		categoryAxis.renderer.grid.template.location = 0;
		categoryAxis.renderer.minGridDistance = 30;
		categoryAxis.renderer.labels.template.horizontalCenter = "right";
		categoryAxis.renderer.labels.template.verticalCenter = "middle";
		categoryAxis.renderer.labels.template.rotation = 270;
		categoryAxis.tooltip.disabled = true;
		categoryAxis.renderer.minHeight = 110;

		var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
		valueAxis.renderer.minWidth = 50;

		// Create series
		var series = chart.series.push(new am4charts.ColumnSeries());
		series.sequencedInterpolation = true;
		series.dataFields.valueY = "visits";
		series.dataFields.categoryX = "country";
		series.tooltipText = "[{categoryX}: bold]{valueY}[/]";
		series.columns.template.strokeWidth = 0;

		series.tooltip.pointerOrientation = "vertical";

		series.columns.template.column.cornerRadiusTopLeft = 10;
		series.columns.template.column.cornerRadiusTopRight = 10;
		series.columns.template.column.fillOpacity = 0.8;

		// on hover, make corner radiuses bigger
		var hoverState = series.columns.template.column.states.create("hover");
		hoverState.properties.cornerRadiusTopLeft = 0;
		hoverState.properties.cornerRadiusTopRight = 0;
		hoverState.properties.fillOpacity = 1;

		series.columns.template.adapter.add("fill", function(fill, target) {
		  return chart.colors.getIndex(target.dataItem.index);
		});

		// Cursor
		chart.cursor = new am4charts.XYCursor();

		}); // end am4core.ready()
		</script>

		<!-- HTML -->
		<div id="chartdiv"></div>

		  <!-- <div id="chart_div" style="width: 900px; height: 500px"></div> -->
    <!-- <div id="curve_chart" style="width: 900px; height: 500px"></div> -->
  </body>
</html>


<form id="form2" name="form2" method="post" action="">
  <p>

    <center>
    <label>
      <input type="text" name="txtKeyword" id="txtKeyword" autocomplete="off" value="<?=$strKeyword?>" />
    </label>
    <label>

        <button type="submit" class="btn btn-warning">ค้นหา</button>


			</center>

            <!--<input type="submit"  name="button" id="button" value="Submit" />-->
    </label>
  </p>

</form>

<div class="container">

<table class="table table-striped table-hover">
<thead>
		<tr>
              <th>วันเดือนปี (เริ่ม-สิ้นสุด)</th>
              <th>เวลา (เริ่ม-สิ้นสุด)</th>
              <th>สถานที่</th>

               <th>ที่อยู่</th>
               <th>เบอร์โทร</th>
               <th>ดูเพิ่มเติม</th>
                <th>แก้ไข</th>
								  <th>ลบ</th>


        </tr>
 </thead>
 <tbody>
        <?php

$sql="select * from rent_order where od_date_start LIKE '%".$strKeyword."%' or od_date_end LIKE '%".$strKeyword."%' or od_time_start LIKE '%".$strKeyword."%' or od_time_end LIKE '%".$strKeyword."%'
or 	od_place LIKE '%".$strKeyword."%' or od_amphoe LIKE '%".$strKeyword."%'";
$result=$db->query($sql);
while($row=$result->fetch_array(MYSQLI_BOTH)){
	?>

        <tr>
 <td><?=$row["od_date_start"]?>--<?=$row["od_date_end"]?></td>
 <td><?=$row["od_time_start"]?>--<?=$row["od_time_end"]?></td>
 <td><?=$row["od_place"]?></td>
 <td><?=$row["od_amphoe"]?></td>
 <td><?=$row["od_number"]?></td>

 <td><a href="?page=info_show&orderID=<?=$row['orderID']?>" class="btn btn-info btn-lg "><img src="img/search.png" width="15" height="15"/></a></td>
 <td><a href="?page=info_edit&orderID=<?=$row['orderID']?>" class="btn btn-secondary btn-lg " onclick="return confirm('คุณแน่ใจจะแก้ไขจริงหรือไม่')"><img src="img/edit-w.png" width="15" height="15"/></a></td>
 <td><a href="?page=info_delete&orderID=<?=$row['orderID']?>" class="btn btn-danger btn-lg " onclick="return confirm('คุณแน่ใจจะลบจริงหรือไม่')"><img src="img/del2.png" width="15" height="15"/></a></td>


 </div>


</tr>

<?php

}
?>

</table>
</div>
</div>


<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<!--
<script>
$("#edit-member1").hide();
$(document).ready(function() {
	$("#edits").click(function(){

   $("#edit-member1").show();

 });

});


</script> -->
