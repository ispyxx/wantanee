
<style>

#margin-top {
  margin-top: 100px;
}

#margin-bottom {
  margin-top: 216px;
}

body {
  font-family: "Chakra Petch", sans-serif;
  color: #777;
}
</style>



<?php
$sql="select * from em_size";
$result=$db->query($sql);
$row=$result->fetch_array(MYSQLI_BOTH);
?>

<?php
$sqll="select * from em_table";
$resultt=$db->query($sqll);
$roww=$resultt->fetch_array(MYSQLI_BOTH);
?>



<?php
$strKeyword=null;
if(isset($_POST["txtKeyword"])){
  $strKeyword=$_POST["txtKeyword"];
}
?>


<?php
$strKeywordd=null;
if(isset($_POST["txtKeyword"])){
  $strKeywordd=$_POST["txtKeyword"];
}
?>

<div id="margin-top">
</div>

<h3>ข้อมูลอุปกรณ์ให้เช่า</h3>



<div class="container col-7">
  <div class="alert alert-secondary" role="alert">
    <div class="row">
      <div class="col">

        <div class="row">

          <h5>เต็นท์</h5>
          <div class="col">
            <div id="margin-add">
              <a class="btn btn-info" href="?page=em_info_t_add" role="button"><img src="img/plus.png" width="15" height="15"/>&nbsp;&nbsp;เพิ่ม</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col">
        <form id="form2" name="form2" method="post" action="">


          <label>
            <input type="text" name="txtKeyword" id="txtKeyword" value="<?=$strKeyword?>" autocomplete="off"/>
          </label>
          <label>
            <button type="submit" class="btn btn-warning">ค้นหา</button>
          </form>
        </div>


      </div>
    </div>

    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>ชื่ออุปกรณ์</th>
          <th>แก้ไข</th>
          <th>ลบ</th>
        </tr>
      </thead>
      <tbody>
        <?php

        $sql="select * 	 from em_size where size_name LIKE '%".$strKeywordd."%'";
        $result=$db->query($sql);
        while($row=$result->fetch_array(MYSQLI_BOTH)){
          ?>

          <tr>
            <td><?=$row["size_name"]?></td>
            <td><a class="btn btn-secondary" href="?page=em_info_tent_edit&sizeID=<?=$row['sizeID']?>"  role="button">แก้ไข</a></td>
            <td><a class="btn btn-danger" href="?page=em_info_tent_del&sizeID=<?=$row['sizeID']?>" role="button">ลบ</a></td>

          </div>
        </tr>
        <?php
      }
      ?>
    </table>
  </div>
<br><br><br>
  <div class="container col-7">
    <div class="alert alert-secondary" role="alert">
      <div class="row">
        <div class="col">

          <div class="row">

            <h5>โต๊ะ</h5>
            <div class="col">
              <div id="margin-add">
                <a class="btn btn-info" href="?page=em_info_table_add" role="button"><img src="img/plus.png" width="15" height="15"/>&nbsp;&nbsp;เพิ่ม</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <form id="form2" name="form2" method="post" action="">


            <label>
              <input type="text" name="txtKeyword" id="txtKeyword" value="<?=$strKeyword?>" autocomplete="off" />
            </label>
            <label>
              <button type="submit" class="btn btn-warning">ค้นหา</button>
            </form>
          </div>


        </div>
      </div>

      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>ชื่ออุปกรณ์</th>
            <th>แก้ไข</th>
            <th>ลบ</th>
          </tr>
        </thead>
        <tbody>
          <?php

          $sql="select * 	 from em_table where table_style LIKE '%".$strKeyword."%'";
          $result=$db->query($sql);
          while($row=$result->fetch_array(MYSQLI_BOTH)){
            ?>

            <tr>
              <td><?=$row["table_style"]?></td>
              <td><a class="btn btn-secondary" href="?page=em_info_table_edit&tableID=<?=$row['tableID']?>"  role="button">แก้ไข</a></td>
              <td><a class="btn btn-danger" href="?page=em_info_table_del&tableID=<?=$row['tableID']?>" role="button">ลบ</a></td>

            </div>
          </tr>
          <?php
        }
        ?>
      </table>
    </div>

      <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
      <!--
      <script>
      $("#edit-member1").hide();
      $(document).ready(function() {
      $("#edits").click(function(){

      $("#edit-member1").show();

    });

  });


</script> -->
