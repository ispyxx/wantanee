

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<!--date-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.12.4.js"></script>
<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!-- วันที่ -->
<script type="text/javascript">
$(document).ready(function(){
  // Date Object
  $('#datepicker1').datepicker({
    dateFormat: "yy-mm-dd",
    minDate: new Date('2017-12-5')
  });

  // Number
  $('#od_date_start').datepicker({
    dateFormat: "yy-mm-dd",
    minDate: 0
  });
});
</script>
<!-- วันที่ -->
<script type="text/javascript">
$(document).ready(function(){
  // Date Object
  $('#datepicker1').datepicker({
    dateFormat: "yy-mm-dd",
    minDate: new Date('2017-12-5')
  });

  // Number
  $('#od_date_end').datepicker({
    dateFormat: "yy-mm-dd",
    minDate: 0
  });
});
</script>


<!-- เรียกข้อมูลในฐานข้อมูลมาทำ dropdown  rent-->
<?php
include ('config.php');
$select_data = "SELECT * FROM em_rentt"
or die ("Error : ".mysqlierror($select_data));
$rs_select = mysqli_query($db, $select_data);
//echo ($query_level);//test query
?>

<!-- เรียกข้อมูลในฐานข้อมูลมาทำ dropdown  amphures-->

<style>
body {
  background-color: #2EA697;
}

#margin-between-bottom {
  margin-bottom: 8px;
}
/*
#margin-between-time {
margin-bottom: px;
} */

#margin-between-top {
  margin-top: 30px;
}
#margin-between-bottom-textbox {
  margin-bottom: 32px;
}
</style>

<script type="text/javascript">
$(function(){
  $("#i_accept").click(function(){ // เมื่อคลิกที่ checkbox id=i_accept
    if($(this).prop("checked")==true){ // ถ้าเลือก
      $("#continue").removeAttr("disabled"); // ให้ปุ่ม id=continue_bt ทำงาน สามารถคลิกได้
    }else{ // ยกเลิกไม่ทำการเลือก
      $("#continue").attr("disabled","disabled");  // ให้ปุ่ม id=continue_bt ไม่ทำงาน
    }
  });
});
</script>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">

<body>


  <hr>


  <div class="container">
    <form action="?page=add_save" method="post" enctype="multipart/form-data" name="form1" id="form1" onSubmit="JavaScript:return fncSubmit();">
      <!-- ฝั่งซ้าย ระบุอุปกรณ์ -->
      <div class="container">
        <div class="row">
          <div style="width: 50%; float:left">
            <div class="row justify-content-center">
              <div class="col-md-11">
                <div class="card">

                  <header class="card-header">
                    <h4 class="card-title mt-2">เช่าอุปกรณ์</h4>
                  </header>



                  <article class="card-body">
                    <br>

                    <div class="row">
                      <div class="col-5">
                        <div class="form-group">

                          <label>เต็นท์</label>
                          <select class="form-control" name="od_size_tentID">
                            <option selected disabled value="">-- ขนาดของเต็นท์ --</option>
                        <?php
                            $sql="select * from em_size";
                            $result=$db->query($sql);
                            while ($row=$result->fetch_array(MYSQLI_BOTH)){
                              ?>

                              <option value="<?php echo $row["sizeID"]; ?>"><?php echo $row["size_name"]; ?></option>

                          <?php }?>

                          </select>
                        </div>
                      </div>

                  <?php
                      $sql="select * from em_color";
                      $result=$db->query($sql);
                      $row=$result->fetch_array(MYSQLI_BOTH);
                   ?>

                      <div class="col-3">
                        <div class="form-group">
                          <div id="margin-between-bottom-textbox"></div>
                          <select class="form-control" name="od_color_tentID">
                            <option selected disabled value="">-- สี --</option>

                            <?php
                                $sql="select * from em_color";
                                $result=$db->query($sql);
                                while ($row=$result->fetch_array(MYSQLI_BOTH)){
                                  ?>
                                  <option value="<?php echo $row['colorID']; ?>"><?php echo $row['color_name']; ?></option>
                            <?php }?>

                          </select>
                        </div>
                      </div>


                      <div class="col-md-3" id="input-number">
                        <div id="margin-between-bottom-textbox"></div>
                        <div id="margin-between-bottom"></div>
                        <input type="number" name="od_amount_tent" id="od_amount_tent" min="1" max="50" style="height: 37px;" placeholder="จำนวน">
                      </div>

                    </div>



                    <hr class="style7">  <!--เส้นใต้-->
                      <div class="row">
                      <div class="col-5">
                        <div class="form-group">
                          <label>โต๊ะ</label>
                          <select class="form-control" name="od_style_tableID">
                            <option selected disabled value="">-- รูปแบบโต๊ะ --</option>

                            <?php
                                $sql="select * from em_table";
                                $result=$db->query($sql);
                                while ($row=$result->fetch_array(MYSQLI_BOTH)){
                                      ?>
                                      <option  value="<?php echo $row['tableID']; ?>"><?php echo $row['table_style']; ?></option>
                                      <?php } ?>

                          </select>
                        </div>
                      </div>

                      <div class="col-md-3" id="input-number">
                        <div id="margin-between-bottom-textbox"></div> <div id="margin-between-bottom"></div> <input type="number" name="od_amount_table" id="od_amount_table" min="1" max="50" style="height: 37px;" placeholder="จำนวน">
                      </div>

                    </div>

                    <hr class="style7">  <!--เส้นใต้-->


                    <div class="row">
                      <div class="col-md-3" id="input-number">
                        เก้าอี้  <div id="margin-between-bottom"></div> <input type="number" name="od_amount_chair" id="od_amount_chair" min="1" max="50" style="height: 37px;" placeholder="จำนวน">
                      </div>
                    </div>
                    <br>
                  </div> <!-- col.//-->
                </div> <!-- row.//-->
              </article>

            </div>
            <!--container end.//-->
            <div id="margin-between-top">
            </div>
            <!-- ฝั่งซ้าย ที่อยู่ -->
            <div class="row justify-content-center">
              <div class="col-md-11">
                <div class="card">

                  <header class="card-header">
                    <h4 class="card-title mt-2">สถานที่</h4>
                  </header>

                  <article class="card-body">
                    <!-- <form action="?page=add" method="post" enctype="multipart/form-data" name="form1" id="form1" onSubmit="JavaScript:return fncSubmit();"> -->
                    <br>
                    <div clss"from">
                      <div class="col-12">
                        <input type="text" class="form-control" placeholder="รายละเอียดสถานที่" name="od_place" autocomplete="off" style="height: 70px;" required>
                      </div> <!-- form-group end.// -->
                      <br>
                      <div class="col-6">
                        <input type="text" class="form-control" placeholder="เบอร์มือถือ" name="od_number" autocomplete="off" min="1" max="10" maxlength="10" required>
                      </div> <!-- form-group end.// -->
                      <br>
                      <div class="col-5">
                        <div class="form-group">

                          <select id="od_amphoe" name="od_amphoe"class="form-control">
                            <option selected disabled="">กรุณาเลือกอำเภอ</option>
                            <option value="เมืองกำแพงเพชร">เมืองกำแพงเพชร</option>	 <option value="ไทรงาม">ไทรงาม</option>			  <option value="คลองลาน">คลองลาน</option>
                            <option value="ขาณุวรลักษบุร">ขาณุวรลักษบุรี</option>		 <option value="คลองขลุง">คลองขลุง</option>		   <option value="พรานกระต่าย">พรานกระต่าย</option>
                            <option value="ลานกระบือ">ลานกระบือ</option>			   <option value="ทรายทองวัฒนา">ทรายทองวัฒนา</option>	<option value="ปางศิลาทอง">ปางศิลาทอง</option>
                            <option value="บึงสามัคคี">บึงสามัคคี</option>				 <option value="โกสัมพีนคร">โกสัมพีนคร</option>
                          </select>
                        </div>
                      </div>
                      <!-- <div class="col-7">
                      <label>เก้าอี้</label>
                      <input type="password" class="form-control" placeholder=" " name="password" required>
                    </div> form-group end.// -->
                  </div>
                </article><!-- form-row end.// -->
                <br><br>
                <hr class="style7">  <!--เส้นใต้-->


              </div> <!-- col.//-->

            </div> <!-- row.//-->


          </div> <!-- <div class="row justify-content-center"> -->


          </div><!-- ซ้าย -->

          <!-- ฝั่งขวา วัน เวลา -->

          <div style="width: 50%; float:right">
            <div class="row justify-content-center">
              <div class="col-md-8">
                <div class="card">

                  <header class="card-header">

                    <h4 class="card-title mt-2">กำหนดงาน</h4>
                  </header>

                  <article class="card-body">
                    <!-- <form action="?page=add" method="post" enctype="multipart/form-data" name="form1" id="form1" onSubmit="JavaScript:return fncSubmit();"> -->
                    <br>
                    <div class"from">
                      <div class="row">
                        <div class="col-md-7">
                          เริ่มเมื่อ: <input type="text" id="od_date_start" name="od_date_start" style="height: 30px;" required autocomplete="off">
                        </div>

                        <div id="margin-between-bottom">
                        </div>
                        <div class="col-md-3" id="input-number">
                          เวลา :
                          <input type="time" id="od_time_start" name="od_time_start" style="height: 30px;" required autocomplete="off">
                        </div>
                      </div>

                      <hr class="style7">  <!--เส้นใต้-->
                      <div class="row">
                        <div class="col-md-7">
                          สิ้นสุดเมื่อ: <div id="margin-between-time"></div><input type="text" id="od_date_end" name="od_date_end" style="height: 30px;" required autocomplete="off">
                        </div>


                        <div class="col-md-3" id="input-number">
                          เวลา :<div id="margin-between-time"></div>
                          <input type="time" id="od_time_end" name="od_time_end" style="height: 30px;" required autocomplete="off">
                        </div>
                      </div>

                    </div> <!-- form-row end.// -->
                    <br>
                    <hr class="style7">  <!--เส้นใต้-->

                    <div class="form-row">
                      <div class="container">
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary btn-lg btn-block"> เช่าอุปกรณ์  </button><br>
                          <div class= "text-right">
                            <a class="btn btn-secondary" href="?page=rental_item" role="button">ย้อนกลับ</a>
                          </div>
                        </div> <!-- form-group// -->
                      </div>

                    </article> <!-- card-body end .// -->

                    <!-- <div class="border-top card-body text-center">Have an account? <a href="?page=main">Log In</a></div> -->
                  </div> <!-- card.// -->
                </div> <!-- col.//-->

              </div> <!-- row.//-->


            </div>
          </div>

        </div>
      </div>
    </form>
  </div>







  <br><br>
</body>
