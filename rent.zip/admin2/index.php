
<?php include('h.php');?>
<body class="hold-transition skin-red sidebar-mini">
  <div class="wrapper">
    <header class="main-header">
      
      <?php include('navbar.php');?>
    </header>
    
    <?php include('menu_left.php');?>
    
    <div class="content-wrapper">
     
      <div class="box-body">
        <div class="small-box bg-blue">
                      <div class="inner">
                        <h3> ยินดีต้อนรับ </h3>
                        <p> 
                        ระบบบริหารจัดการหลังร้านจำหน่ายกลุ่มสินค้า OTOP ตำบลตลุกกลางทุ่ง
                        </p>
                      </div>
                      <div class="icon">
                        <i class="ion ion-person-add"></i>
                      </div>
                     
                    </div>
                  </div>
     
        
      </section>
      <!-- /.content -->
    </div>
    <?php include('footer.php');?>