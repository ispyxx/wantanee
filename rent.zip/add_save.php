<style>
			body {
				background-color: #2EA697;
			}
			#margin-top {
			  margin-top: 150px;
			}

			#margin-bottom {
			  margin-top: 216px;
			}
</style>

<div id="margin-bottom">
	</div>
<div class="container">
				<div class="alert alert-success" role="alert">
					<div class="col-7">
            <!-- if(isset($_POST['od_place']) && isset($_POST['od_number']) && !empty($_POST['od_place']) && !empty($_POST['od_number'])){ -->
            <!-- values('$_POST[od_date_start]', '$_POST[od_time_start]', '$_POST[od_date_end]', '$_POST[od_time_end]', '$_POST[od_place]', '$_POST[od_amphoe]', '$_POST[od_number]', '$_POST[od_size_tent]', '$_POST[od_color_tent]', '$_POST[od_amount_tent]', '$_POST[od_style_table]', '$_POST[od_amount_table]', '$_POST[od_amount_chair]')"; -->
            <!-- values('$od_date_start', '$od_time_start', '$od_date_end', '$od_time_end', '$od_place', '$od_amphoe', '$od_number', '$od_size_tent', '$od_color_tent', '$od_amount_tent', '$od_style_table', '$od_amount_table', '$od_amount_chair')"; -->

<?php


$sql="insert into rent_order(od_date_start, od_time_start, od_date_end, od_time_end, od_place, od_amphoe, od_number, od_amount_tent, od_amount_table, od_amount_chair, member_id)
     values('$_POST[od_date_start]', '$_POST[od_time_start]', '$_POST[od_date_end]', '$_POST[od_time_end]', '$_POST[od_place]', '$_POST[od_amphoe]', '$_POST[od_number]', '$_POST[od_amount_tent]', '$_POST[od_amount_table]', '$_POST[od_amount_chair]', $_SESSION[sess_userID])";

		 if (	$result=$db->query($sql)===true) {
			 $last_id=$db->insert_id;
		 	// echo $last_id; exit;


			if (!empty($_POST["od_size_tentID"]) ) {
				$sql="update rent_order set od_size_tentID='$_POST[od_size_tentID]' where orderID = $last_id";
				$result=$db->query($sql);

			}

			if (!empty($_POST["od_color_tentID"]) ) {
				$sql="update rent_order set od_color_tentID='$_POST[od_color_tentID]' where orderID = $last_id";
				$result=$db->query($sql);

			}

			if (!empty($_POST["od_style_tableID"]) ) {
				$sql="update rent_order set od_style_tableID='$_POST[od_style_tableID]' where orderID = $last_id";
				$result=$db->query($sql);

			}



		 }

		$result=$db->query($sql);
    	if($result){
    	echo "บันทึกข้อมูล สำเร็จ";
      echo "<meta http-equiv='refresh' content='2;url=?page=rental_item0' />";
    	}
    	else{
    	echo "บันทึกข้อมูล ไม่สำเร็จ";
      echo "<meta http-equiv='refresh' content='2;url=?page=add2' />";
    	}

		 // echo $sql; exit​;

    ?>
		<!-- <meta http-equiv="refresh" content="2;url=?page=rental_item" /> -->
    </div>
  </div>
</div>
<div id="margin-bottom">
  </div>
