
<style>

#margin-top {
	margin-top: 100px;
}

#margin-bottom {
	margin-top: 216px;
}
</style>



<?php
	 $sql="select * from member";
	 $result=$db->query($sql);
	 $row=$result->fetch_array(MYSQLI_BOTH);
 ?>



<?php
$strKeyword=null;
if(isset($_POST["txtKeyword"])){
$strKeyword=$_POST["txtKeyword"];
}
?>

<div id="margin-top">
</div>

<h3>ข้อมูลการเช่า</h3>

<html>
  <?php
      $jan=0;
      $fub=0;
      $mar=0;
      $Apr=0;
      $May=0;
      $Jun=0;

      $Jul=0;
      $Aug=0;
      $Sep=0;
      $Oct=0;
      $Nov=0;
      $Dec=0;

      $sql="select month(od_date_start) from rent_order";
      $result=$db->query($sql);
      while($row=$result->fetch_array(MYSQLI_ASSOC)){
        if($row["month(od_date_start)"]==1){
          $jan++;
        }
        if($row["month(od_date_start)"]==2){
          $fub++;
        }
        if($row["month(od_date_start)"]==3){
          $mar++;
        }
        if($row["month(od_date_start)"]==4){
          $Apr++;
        }
        if($row["month(od_date_start)"]==5){
          $May++;
        }
        if($row["month(od_date_start)"]==6){
          $Jun++;
        }


        if($row["month(od_date_start)"]==7){
          $Jul++;
        }
        if($row["month(od_date_start)"]==8){
          $Aug++;
        }
        if($row["month(od_date_start)"]==9){
          $Sep++;
        }
        if($row["month(od_date_start)"]==10){
          $Oct++;
        }
        if($row["month(od_date_start)"]==11){
          $Nov++;
        }
        if($row["month(od_date_start)"]==12){
          $Dec++;
        }

}
      $all=$jan+$fub+$mar+$Apr+$May+$Jun+$Jul+$Aug+$Sep+$Oct+$Nov+$Dec;
?>


  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['เดือน', 'จำนวน(คน)'],
          ['มกราคม',  <?=$jan?>],
          ['กุมภาพันธ์', <?=$fub?>],
          ['มีนาคม',  <?=$mar?>],
          ['เมษายน',  <?=$Apr?>],
          ['พฤษภาคม',  <?=$May?>],
          ['มิถุนายน',  <?=$Jun?>],

          ['กรกฎาคม',  <?=$Jul?>],
          ['สิงหาคม',  <?=$Aug?>],
          ['กันยายน',  <?=$Sep?>],
          ['ตุลาคม',  <?=$Oct?>],
          ['พฤศจิกายน',  <?=$Nov?>],
          ['ธันวาคม',  <?=$Dec?>]
        ]);

        var options = {
          title: 'จำนวน(คน)',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="curve_chart" style="width: 900px; height: 500px"></div>
  </body>
</html>


<form id="form2" name="form2" method="post" action="">
  <p>

    <center>
    <label>
      <input type="text" name="txtKeyword" id="txtKeyword" value="<?=$strKeyword?>" />
    </label>
    <label>

        <button type="submit" class="btn btn-warning">ค้นหา</button>


			</center>

            <!--<input type="submit"  name="button" id="button" value="Submit" />-->
    </label>
  </p>

</form>

<div class="container">

<table class="table table-striped table-hover">
<thead>
		<tr>
              <th>วันเดือนปี (เริ่ม-สิ้นสุด)</th>
              <th>เวลา (เริ่ม-สิ้นสุด)</th>
              <th>สถานที่</th>

               <th>ที่อยู่</th>
               <th>เบอร์โทร</th>
               <th></th>
                <th></th>


        </tr>
 </thead>
 <tbody>
        <?php

$sql="select * from rent_order where od_date_start LIKE '%".$strKeyword."%' or od_date_end LIKE '%".$strKeyword."%' or od_time_start LIKE '%".$strKeyword."%' or od_time_end LIKE '%".$strKeyword."%'
or 	od_place LIKE '%".$strKeyword."%' or od_amphoe LIKE '%".$strKeyword."%'";
$result=$db->query($sql);
while($row=$result->fetch_array(MYSQLI_BOTH)){
	?>

        <tr>
 <td><?=$row["od_date_start"]?>--<?=$row["od_date_end"]?></td>
 <td><?=$row["od_time_start"]?>--<?=$row["od_time_end"]?></td>
 <td><?=$row["od_place"]?></td>
 <td><?=$row["od_amphoe"]?></td>
 <td><?=$row["od_number"]?></td>

 <td><a class="btn btn-secondary" href="?page=ad_member_edit&memberID=<?=$row['memberID']?>"  role="button">ดูเพิ่มเติม</a></td>
 <td><a class="btn btn-danger" href="?page=ad_member_del&memberID=<?=$row['memberID']?>" role="button">ลบ</a></td>

 </div>


</tr>

<?php

}
?>

</table>
</div>
</div>


<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<!--
<script>
$("#edit-member1").hide();
$(document).ready(function() {
	$("#edits").click(function(){

   $("#edit-member1").show();

 });

});


</script> -->
