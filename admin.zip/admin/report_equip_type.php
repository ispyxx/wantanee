<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" />


<style>
#margin-top{
  margin-top: 100px;
  background-color: #2EA697;
}

#margin-topp{
  margin-bottom:  30px;
}

#margin-left{
  margin-left: 135px;
}

</style>


<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Table</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" />
</head>

<body>


<div id="margin-top">
</div>
<div id="bg-header">
      <div class="container">
      <div id="margin-left"><h2>รายงานสถิติการเช่าอุปกรณ์จำแนกตามประเภท</h2></div>
      </div>
  </div>
  <div id="margin-topp">
  </div>


<div class="container">
<form>
  <div class="row">
  <input type="text" name="" style="Width:300px; height:50px;"/>
        <div class="col-2">
        <button type="submit" class="btn btn-primary btn-block"> ค้นหา  </button><br>
      </div>
      </div>
</form>
</div>

<div class="container col-9">
  <table class="table table-striped table-hover">
    <thead>
        <tr>
          <th scope="col">ประจำเดือน</th>
          <th >จำนวน (คน)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>มกราคม</td>
          <td></td>
        </tr>

        <tr>
          <td>กุมภาพันธ์</td>
          <td></td>
        </tr>

        <tr>
          <td>มีนาคม</td>
          <td></td>
        </tr>

        <tr>
            <td>เมษายน</td>
            <td></td>
        </tr>



        <tr>
          <td colspan="2"><b>รวมทั้งหมด</b></td>
        </tr>
      </tbody>
</table>
</div>
</body>
